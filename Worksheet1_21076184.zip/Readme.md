﻿# Button Masher

This is a simple reaction game that challenges players to press the correct button when a light flashes on the left or right side of the micro:bit.
The game lasts for 9 seconds, and the player's score is based on the number of correct button presses. 
Score can be negative if the player presses incorrect button more then correct button.


## Materials Required

-   micro:bit
-   USB cable

## Instructions
1.  Connect your micro:bit to your computer using the USB cable.
2.  Copy and paste the code into the [MicroPython editor](https://python.microbit.org/v/2.0).
3.  Click on "Download" to download the hex file.
4.  Drag and drop the hex file onto your micro:bit to load the game onto the device.
5.  Hold the micro:bit in your hand and get ready to play!
6.  When the game starts, a "GET READY" message will scroll across the screen. When the message disappears, the game will begin.
7.  If a light flashes on the left side of the micro:bit, press button A as quickly as possible. If a light flashes on the right side of the micro:bit, press button B.
8.  if light flashes on both sides of the micro:bit, press A and B at the same time as quickly as possible.
10.  Your score will be displayed on the screen at the end of the game.

